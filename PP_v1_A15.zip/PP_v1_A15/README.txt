LINFO1212 - Projet d'approfondissement en sciences informatiques
Groupe A15

DATE : 06-10-2023

MEMBRES :
Meurice Augustin
Kamhi Mohamed
Lacroix Ethan


Projet préparatoire v1: FIX'IT

description du projet:
Le projet consiste en une maquette d'un site web basé sur le site "https://fixmystreet.brussels/" pour créer son équivalent pour la ville de Louvain-La-Neuve.


HTML:
Le projet se compose de trois pages HTML (mainpage, loginpage et creationpage) qui servent respectivement à afficher la liste des incidents, se connecter ou s'enregistrer sur le site et à signaler un nouvel incident.

CSS:
Le style des pages HTML est séparé en trois fichiers CSS qui illustrent les différents styles des pages.

SPECIFICATION:
Le projet est également composé de trois fontionnalités essentielles et pertinentes au bon fonctionnement du site.

OTHER:
Un fichier image logo.png est également utilisé dans les pages HTML


difficutlés rencontrées et sources:

- Dans le fichier loginpage.html, la balise <form> et sa descendance du bouton "se connecter" a été fortement inspirée par CHATGPT. Cependant cette partie du code issue de l'outil CHATGPT a été compris par tous dans son entièreté.
- Nous avons également rencontrés des difficultés à mettre en place l'entête du site notamment les éléments la constituant. Nous avons finalement réussi à mettre partiellement en place les éléments mais nous savons que nos pages ne sont pas addaptives en fonction de l'ordinateur et du navigateur utilisé.
- Une des améliorations évidentes serait la disposition et l'affichage des différents éléments de notre site.